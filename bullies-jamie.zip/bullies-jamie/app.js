const express = require("express");
const app = express();
const http = require("http");
const server = http.createServer(app);
const io = require('socket.io')(server);
var grabbed =false;


const LISTEN_PORT = 8080;

server.listen(LISTEN_PORT);
console.log("listen on port: "+LISTEN_PORT);

//set root folder of all web files to public folder
app.use(express.static(__dirname + "\public"));

app.use("/scripts", express.static('./scripts/'));
app.use("/models", express.static('./models/'));
app.use("/js", express.static('./js/'));
app.use("/assets", express.static('./assets/'));

//how to run node .\app.js

//set default route
app.get("/", function(req,res){
    res.sendFile(__dirname + "/public/index.html");
});

app.get( '/VR', function( req, res ){ 
    res.sendFile( __dirname + '/public/vr.html' );
});

app.get( '/MOBILE', function( req, res ){ 
    res.sendFile( __dirname + '/public/mobile.html' );
});




//socket stuff
io.on('connection',(socket) => {
    console.log(socket.id + 'is connencted.');

    socket.on('disconnect', () =>{
        console.log(socket.id + 'is disconnected.')
    });

    socket.on('reset', (data) => {
        if (data != null && !grabbed){
            io.sockets.emit('test',data);
        }
    });

    socket.on('leftcon', (data) => {
        if (data != null){
            io.sockets.emit('updateleft',data);
        }
    });

    socket.on('rightcon', (data) => {
        if (data != null){
            io.sockets.emit('updateright',data);
        }
    });

    socket.on('grabbed', (data) => {
        grabbed = true;
        console.log('grabbed him! distance: '+data);
        io.sockets.emit('grabem',data);
    });

    socket.on('letgo', (data) => {
        grabbed = false;
        console.log('let him go');
        io.sockets.emit('leggoem',data);
    });

    socket.on('updatepos', (data) => {
        if(grabbed){
            io.sockets.emit('movehim',data);
        }
    });



    

});
