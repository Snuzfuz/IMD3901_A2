var moving = false;
var moveTo;
var bullyPos;
let follow = false;

AFRAME.registerComponent('click-to-move', {
  schema: {},
  
  init: function () {
    this.el.addEventListener('click', function() {  
        moving = true;
        var cursor = document.querySelector('#mouse');
        var bully = document.querySelector('#bully');
        var elToWatch = document.querySelector('#plane')
        //bully.removeAttribute('dynamic-body');
        //bully.setAttribute('static-body',"");
        bullyPos = bully.getAttribute('position');
        var intersection = cursor.components.raycaster.getIntersection(elToWatch);
        moveTo = intersection.point;
        

    });

  },
  tick: function (delta) {
    
    var bully = document.querySelector('#bully');
    var rig = document.querySelector('#rig');
    if(moving){
      bully.setAttribute('position',bullyPos.lerp({x: moveTo.x, y: 0.5, z: moveTo.z},0.05));
      bully.components["dynamic-body"].syncToPhysics();
      if(bullyPos == moveTo){
        moving = false;
      }
    }

    

  }
});