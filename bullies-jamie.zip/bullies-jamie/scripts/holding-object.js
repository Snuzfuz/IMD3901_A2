AFRAME.registerComponent('holding-object', {
    init: function () {
      const Context_AF = this;
      // Solution for Creating Entities.
      var sceneEl = document.querySelector('a-scene'); 
      Context_AF.isHolding = false; 
      var data = this.data;
      var holdPoint = document.querySelector('hold-point'); 
        //listen on click
        Context_AF.el.addEventListener('click', function() {
          console.log("Pushing");

          var impulseEx = new CANNON.Vec3(0, 1, -1);
          this.body.applyImpulse(impulseEx, this.body.position);
      });
    }
  });