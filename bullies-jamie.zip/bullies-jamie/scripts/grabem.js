

AFRAME.registerComponent('followme', {
  schema: {identity: {default:''}},
  
  init: function () {
    
  },
  tick: function (delta) {
    var bully = document.querySelector('#bully');
    var rig = document.querySelector('#rig');
    bullyPos = bully.getAttribute('position');
    rig.setAttribute('position', {x: bullyPos.x, y: bullyPos.y+0.5, z: bullyPos.z+1.5});

  }
    
});

